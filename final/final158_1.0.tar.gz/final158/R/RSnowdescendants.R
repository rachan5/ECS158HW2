RSnowdescendants <-
function (phy, node, type=c("tips","children","all"),cls) {
    type <- match.arg(type)

    ## look up nodes, warning about and excluding invalid nodes
    oNode <- node
    node <- getNode(phy, node, missing="warn")
    isValid <- !is.na(node)
    node <- as.integer(node[isValid])

    if (type == "children") {
        res <- lapply(node, function(x) children(phy, x))
        ## if just a single node, return as a single vector
        if (length(res)==1) res <- res[[1]]
    } else {
        ## edge matrix must be in preorder for the C function!
        #if (phy@order=="preorder") {
            edge <- phy@edge
        #} else {
        #    edge <- reorder(phy, order="postorder")@edge
        #}
        ## extract edge columns
        ancestor <- as.integer(edge[, 1])
        descendant <- as.integer(edge[, 2])
        
        ## return indicator matrix of ALL descendants (including self)
        #isDes <- .Call("descendants", node, ancestor, descendant)
        clusterExport(cls,c("node", "ancestor", "descendant","setmyid","SNOW"),envir=environment())
        dexgrps <- splitIndices(length(ancestor),length(cls))
        rootdex <- which(phy@edge[,1] == 0)
        clusterApply(cls,1:length(cls),setmyid)
        newisDes <- clusterApply(cls,dexgrps,SNOW,length(ancestor),rootdex,"descendants")
        isDes <- (matrix(Reduce('+',newisDes),nrow=length(ancestor),ncol=1))
        storage.mode(isDes) <- "logical"

        ## for internal nodes only, drop self (not sure why this rule?)
        int.node <- intersect(node, nodeId(phy, "internal"))
        isDes[cbind(match(int.node, descendant),
            match(int.node, node))] <- FALSE
        
        ## if only tips desired, drop internal nodes
        if (type=="tips") {
            isDes[descendant %in% nodeId(phy, "internal"),] <- FALSE
        }
        ## res <- lapply(seq_along(node), function(n) getNode(phy,
        ##     descendant[isDes[,n]]))
        res <- getNode(phy, descendant[isDes[, seq_along(node)]])
    }
    ## names(res) <- as.character(oNode[isValid])

    res
}
