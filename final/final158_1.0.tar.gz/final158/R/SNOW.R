SNOW <-
function(x,size,root,type=c("descendants")){
    ans <- rep(0,size)
    mystart <- (myid-1)*length(x)+1
    myend <- myid*length(x)
    
    type <- match.arg(type)
    if (type == "descendants"){
        v1 <- descendant
        v2 <- ancestor
        #initalization
        temp <- v1[mystart:myend]
        
        #second and beyond iteration
        for (j in 1:size){ 
            if (node %in% temp){
                setthese <- which(temp == node) + mystart-1
                ans[setthese] <- 1
            }
            blah <- rep(-1,length(temp))
            for (i in (1:length(temp))){
                matched_pos <- which(v1 == temp[i])
                if (length(matched_pos) != 0){
                    blah[which(temp == temp[i])] <- matched_pos
                }
                else{#matched_pos == 0
                    ## R is 1 INDEXED!
                    if (type == "descendants"){
                        blah[i] <- 1
                    }
                }
            }#for i 
            #"go to your parents set"
            difference <- length(temp) - length(v2[blah])
            temp <- v2[blah]
            if (difference > 0){
                temp <- c(rep(0,difference),temp)
            }
            if (node %in% temp){
                setthese <- which(temp == node) + mystart-1
                ans[setthese] <- 1
            }
        }#j loop
    }#new endif for type==descendants
    return(ans)
}
