OMPshortestPath <-
function(phy, node1, node2){
  ## conversion from phylo, phylo4 and phylo4d
  if (class(phy) == "phylo4d") {
    x <- extractTree(phy)
  }
  else if (class(phy) != "phylo4"){
    x <- as(phy, "phylo4")
  }

    ## some checks
    ## if (is.character(checkval <- checkPhylo4(x))) stop(checkval) # no need
    t1 <- getNode(x, node1)
    t2 <- getNode(x, node2)
    if(any(is.na(c(t1,t2)))) stop("wrong node specified")
    if(t1==t2) return(NULL)

    ## main computations
    comAnc <- OMPMRCA(x, t1, t2) # common ancestor
    desComAnc <- OMPdescendants(x, comAnc, type="all")
    ancT1 <- OMPancestors(x, t1, type="all")
    path1 <- intersect(desComAnc, ancT1) # path: common anc -> t1

    ancT2 <- OMPancestors(x, t2, type="all")
    path2 <- intersect(desComAnc, ancT2) # path: common anc -> t2

    res <- union(path1, path2) # union of the path
    ## add the common ancestor if it differs from t1 or t2
    if(!comAnc %in% c(t1,t2)){
        res <- c(comAnc,res)
    }

    res <- getNode(x, res)

    return(res)
}
