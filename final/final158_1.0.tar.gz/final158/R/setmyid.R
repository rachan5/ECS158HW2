setmyid <-
function(i){
    myid <<- i
}
